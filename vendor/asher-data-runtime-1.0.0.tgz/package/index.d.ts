export type Domain = 'notifications' | 'chat' | 'support' | 'maintenance' | 'inspections' | 'finance' | 'dashboard' | 'applications' | 'community' | 'analytics' | 'verification' | 'payment' | 'capture';
export const policies: Readonly<Record<Domain, { staleMs: number; reconcileMs: number }>>;
export const eventDomains: Readonly<Record<string, Domain[]>>;
export interface WatchOptions {
  /** Must include account ID and resource ID for resources with different loaders. */
  key: string;
  domain: Domain;
  load: (signal: AbortSignal) => unknown | Promise<unknown>;
  isActive?: () => boolean;
  onError?: (error: unknown) => void;
  immediate?: boolean;
  intervalMs?: number;
}
export interface Coordinator {
  watch(options: WatchOptions): () => void;
  invalidate(domains: Domain[]): void;
  resume(): void;
  bindSocket(socket: { on(event: string, handler: (...args: any[]) => void): any; off(event: string, handler: (...args: any[]) => void): any }): () => void;
  dispose(): void;
  size(): number;
}
export interface CoordinatorOptions {
  isActive?: () => boolean;
  maxConcurrent?: number;
  now?: () => number;
  timers?: { setTimeout(callback: () => void, delay: number): any; clearTimeout(id: any): void };
}
export function createCoordinator(options?: CoordinatorOptions): Coordinator;
export function createBrowserCoordinator(options?: CoordinatorOptions & { document?: Document }): Coordinator;
