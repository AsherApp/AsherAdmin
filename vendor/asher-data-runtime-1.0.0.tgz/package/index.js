'use strict';

// Events accelerate freshness; periodic reconciliation recovers missed delivery.
const policies = Object.freeze({
  notifications: { staleMs: 30000, reconcileMs: 120000 },
  chat: { staleMs: 15000, reconcileMs: 120000 },
  support: { staleMs: 30000, reconcileMs: 120000 },
  maintenance: { staleMs: 30000, reconcileMs: 120000 },
  inspections: { staleMs: 30000, reconcileMs: 120000 },
  finance: { staleMs: 30000, reconcileMs: 120000 },
  dashboard: { staleMs: 60000, reconcileMs: 300000 },
  applications: { staleMs: 30000, reconcileMs: 60000 },
  community: { staleMs: 60000, reconcileMs: 120000 },
  analytics: { staleMs: 300000, reconcileMs: 600000 },
  verification: { staleMs: 15000, reconcileMs: 30000 },
  payment: { staleMs: 0, reconcileMs: 10000 },
  capture: { staleMs: 0, reconcileMs: 2000 },
});

const eventDomains = Object.freeze({
  notification: ['notifications', 'dashboard'],
  payment_notification: ['notifications', 'finance', 'dashboard'],
  // Backend payment services emit the singular form. Keep the historical
  // alias during rolling client upgrades so either event refreshes finance.
  wallet_update: ['finance', 'dashboard'],
  wallet_updated: ['finance', 'dashboard'],
  privateMessage: ['chat', 'notifications'],
  message_read: ['chat'],
  ticket_created: ['support'],
  ticket_message_added: ['support'],
  ticket_status_updated: ['support'],
  maintenance_updated: ['maintenance', 'dashboard'],
  inspection_updated: ['inspections', 'dashboard'],
});

/** No socket/auth dependency: adapters supply a loader and visibility predicate.
 * One timer and at most one request per registered key. Unsubscribe cancels work.
 * Errors are delivered to onError; retries back off instead of hammering the API.
 */
function createCoordinator(options = {}) {
  const entries = new Map();
  const timers = options.timers || { setTimeout, clearTimeout };
  const now = options.now || Date.now;
  const visible = options.isActive || (() => true);
  let disposed = false;
  let running = 0;
  const maxConcurrent = options.maxConcurrent || 4;

  function cancelTimer(entry) {
    if (entry.timer !== null) timers.clearTimeout(entry.timer);
    entry.timer = null;
  }
  function schedule(entry, delay) {
    cancelTimer(entry);
    if (disposed || !entries.has(entry.key)) return;
    entry.timer = timers.setTimeout(() => { entry.timer = null; void run(entry); }, Math.max(0, delay));
  }
  function isActive(entry) {
    return visible() && [...entry.subscribers].some(s => !s.isActive || s.isActive());
  }
  async function run(entry) {
    if (disposed || !entries.has(entry.key)) return;
    if (entry.controller) { entry.dirty = true; return; }
    if (!isActive(entry)) { schedule(entry, entry.interval); return; }
    if (running >= maxConcurrent) { schedule(entry, 100); return; }
    const controller = new AbortController();
    entry.controller = controller;
    entry.dirty = false;
    running++;
    try {
      // Use a live subscriber's loader so unmounted component closures expire.
      const subscriber = [...entry.subscribers].find(s => !s.isActive || s.isActive());
      await subscriber.load(controller.signal);
      entry.failures = 0;
      entry.lastSuccess = now();
    } catch (error) {
      if (!controller.signal.aborted) {
        entry.failures++;
        for (const subscriber of entry.subscribers) subscriber.onError?.(error);
      }
    } finally {
      running--;
      entry.controller = null;
      if (entries.get(entry.key) === entry) {
        const backoff = Math.min(600000, entry.interval * Math.pow(2, Math.min(entry.failures, 5)));
        schedule(entry, entry.dirty && !entry.failures ? 150 : backoff);
      }
    }
  }
  function watch(config) {
    if (disposed) throw new Error('Data coordinator is disposed');
    if (!config.key || typeof config.load !== 'function') throw new Error('A scoped key and loader are required');
    const policy = policies[config.domain];
    if (!policy) throw new Error('Unknown data domain: ' + config.domain);
    let entry = entries.get(config.key);
    if (entry && entry.domain !== config.domain) throw new Error('Data key reused across domains');
    if (!entry) {
      entry = { key: config.key, domain: config.domain, subscribers: new Set(), interval: config.intervalMs || policy.reconcileMs, timer: null, controller: null, failures: 0, dirty: false, lastSuccess: 0 };
      entries.set(config.key, entry);
    }
    entry.subscribers.add(config);
    if (entry.subscribers.size === 1) schedule(entry, config.immediate === false ? entry.interval : 0);
    let released = false;
    return () => {
      if (released) return;
      released = true;
      entry.subscribers.delete(config);
      if (!entry.subscribers.size) {
        cancelTimer(entry); entries.delete(entry.key); entry.controller?.abort();
      }
    };
  }
  function invalidate(domains) {
    const selected = new Set(domains);
    for (const entry of entries.values()) {
      if (!selected.has(entry.domain)) continue;
      if (entry.controller) entry.dirty = true;
      else if (!entry.failures) schedule(entry, 150);
    }
  }
  function resume() {
    if (!visible()) return;
    for (const entry of entries.values()) {
      const stale = policies[entry.domain].staleMs;
      if (now() - entry.lastSuccess >= stale && !entry.controller && !entry.failures) schedule(entry, 150);
    }
  }
  function bindSocket(socket) {
    const handlers = Object.entries(eventDomains).map(([name, domains]) => {
      const handler = () => invalidate(domains); socket.on(name, handler); return [name, handler];
    });
    const changed = payload => {
      if (payload?.version !== 1 || !Array.isArray(payload.domains)) return;
      invalidate(payload.domains.filter(domain => Object.hasOwn(policies, domain)));
    };
    socket.on('data:changed', changed);
    socket.on('connect', resume);
    return () => {
      handlers.forEach(([name, handler]) => socket.off(name, handler));
      socket.off('data:changed', changed); socket.off('connect', resume);
    };
  }
  function dispose() {
    disposed = true;
    for (const entry of entries.values()) { cancelTimer(entry); entry.controller?.abort(); }
    entries.clear();
  }
  return { watch, invalidate, resume, bindSocket, dispose, size: () => entries.size };
}

function createBrowserCoordinator(options = {}) {
  const doc = options.document || (typeof document !== 'undefined' ? document : undefined);
  const coordinator = createCoordinator({ ...options, isActive: () => !doc?.hidden && (!options.isActive || options.isActive()) });
  const visible = () => coordinator.resume();
  doc?.addEventListener('visibilitychange', visible);
  const dispose = coordinator.dispose;
  coordinator.dispose = () => { doc?.removeEventListener('visibilitychange', visible); dispose(); };
  return coordinator;
}

module.exports = { policies, eventDomains, createCoordinator, createBrowserCoordinator };
