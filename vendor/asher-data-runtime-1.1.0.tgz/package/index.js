'use strict';

// Events accelerate freshness; periodic reconciliation recovers missed delivery.
const policies = Object.freeze({
  notifications: { staleMs: 30000, reconcileMs: 120000 },
  chat: { staleMs: 15000, reconcileMs: 120000 },
  support: { staleMs: 30000, reconcileMs: 120000 },
  maintenance: { staleMs: 30000, reconcileMs: 120000 },
  inspections: { staleMs: 30000, reconcileMs: 120000 },
  finance: { staleMs: 30000, reconcileMs: 120000 },
  dashboard: { staleMs: 60000, reconcileMs: 300000 },
  applications: { staleMs: 30000, reconcileMs: 60000 },
  community: { staleMs: 60000, reconcileMs: 120000 },
  analytics: { staleMs: 300000, reconcileMs: 600000 },
  verification: { staleMs: 15000, reconcileMs: 30000 },
  payment: { staleMs: 0, reconcileMs: 10000 },
  capture: { staleMs: 0, reconcileMs: 2000 },
});

const eventDomains = Object.freeze({
  notification: ['notifications', 'dashboard'],
  payment_notification: ['notifications', 'finance', 'dashboard'],
  // Backend payment services emit the singular form. Keep the historical
  // alias during rolling client upgrades so either event refreshes finance.
  wallet_update: ['finance', 'dashboard'],
  wallet_updated: ['finance', 'dashboard'],
  privateMessage: ['chat', 'notifications'],
  message_read: ['chat'],
  ticket_created: ['support'],
  ticket_message_added: ['support'],
  ticket_status_updated: ['support'],
  maintenance_updated: ['maintenance', 'dashboard'],
  inspection_updated: ['inspections', 'dashboard'],
});

/** No socket/auth dependency: adapters supply a loader and visibility predicate.
 * One timer and at most one request per registered key. Unsubscribe cancels work.
 * Errors are delivered to onError; retries back off instead of hammering the API.
 */
function createCoordinator(options = {}) {
  const entries = new Map();
  const timers = options.timers || { setTimeout, clearTimeout };
  const now = options.now || Date.now;
  const visible = options.isActive || (() => true);
  let disposed = false;
  let running = 0;
  const maxConcurrent = options.maxConcurrent || 4;

  function cancelTimer(entry) {
    if (entry.timer !== null) timers.clearTimeout(entry.timer);
    entry.timer = null;
  }
  function schedule(entry, delay) {
    cancelTimer(entry);
    if (disposed || !entries.has(entry.key)) return;
    entry.timer = timers.setTimeout(() => { entry.timer = null; void run(entry); }, Math.max(0, delay));
  }
  function isActive(entry) {
    return visible() && [...entry.subscribers].some(s => !s.isActive || s.isActive());
  }
  async function run(entry) {
    if (disposed || !entries.has(entry.key)) return;
    if (entry.controller) { entry.dirty = true; return; }
    if (!isActive(entry)) { schedule(entry, entry.interval); return; }
    if (running >= maxConcurrent) { schedule(entry, 100); return; }
    const controller = new AbortController();
    entry.controller = controller;
    entry.dirty = false;
    running++;
    try {
      // Use a live subscriber's loader so unmounted component closures expire.
      const subscriber = [...entry.subscribers].find(s => !s.isActive || s.isActive());
      await subscriber.load(controller.signal);
      entry.failures = 0;
      entry.lastSuccess = now();
    } catch (error) {
      if (!controller.signal.aborted) {
        entry.failures++;
        for (const subscriber of entry.subscribers) subscriber.onError?.(error);
      }
    } finally {
      running--;
      entry.controller = null;
      if (entries.get(entry.key) === entry) {
        const backoff = Math.min(600000, entry.interval * Math.pow(2, Math.min(entry.failures, 5)));
        schedule(entry, entry.dirty && !entry.failures ? 150 : backoff);
      }
    }
  }
  function watch(config) {
    if (disposed) throw new Error('Data coordinator is disposed');
    if (!config.key || typeof config.load !== 'function') throw new Error('A scoped key and loader are required');
    const policy = policies[config.domain];
    if (!policy) throw new Error('Unknown data domain: ' + config.domain);
    let entry = entries.get(config.key);
    if (entry && entry.domain !== config.domain) throw new Error('Data key reused across domains');
    if (!entry) {
      entry = { key: config.key, domain: config.domain, subscribers: new Set(), interval: config.intervalMs || policy.reconcileMs, timer: null, controller: null, failures: 0, dirty: false, lastSuccess: 0 };
      entries.set(config.key, entry);
    }
    entry.subscribers.add(config);
    if (entry.subscribers.size === 1) schedule(entry, config.immediate === false ? entry.interval : 0);
    let released = false;
    return () => {
      if (released) return;
      released = true;
      entry.subscribers.delete(config);
      if (!entry.subscribers.size) {
        cancelTimer(entry); entries.delete(entry.key); entry.controller?.abort();
      }
    };
  }
  function invalidate(domains) {
    const selected = new Set(domains);
    for (const entry of entries.values()) {
      if (!selected.has(entry.domain)) continue;
      if (entry.controller) entry.dirty = true;
      else if (!entry.failures) schedule(entry, 150);
    }
  }
  function resume() {
    if (!visible()) return;
    for (const entry of entries.values()) {
      const stale = policies[entry.domain].staleMs;
      if (now() - entry.lastSuccess >= stale && !entry.controller && !entry.failures) schedule(entry, 150);
    }
  }
  function bindSocket(socket) {
    const handlers = Object.entries(eventDomains).map(([name, domains]) => {
      const handler = () => invalidate(domains); socket.on(name, handler); return [name, handler];
    });
    const changed = payload => {
      if (payload?.version !== 1 || !Array.isArray(payload.domains)) return;
      invalidate(payload.domains.filter(domain => Object.hasOwn(policies, domain)));
    };
    socket.on('data:changed', changed);
    socket.on('connect', resume);
    return () => {
      handlers.forEach(([name, handler]) => socket.off(name, handler));
      socket.off('data:changed', changed); socket.off('connect', resume);
    };
  }
  function dispose() {
    disposed = true;
    for (const entry of entries.values()) { cancelTimer(entry); entry.controller?.abort(); }
    entries.clear();
  }
  return { watch, invalidate, resume, bindSocket, dispose, size: () => entries.size };
}

function createBrowserCoordinator(options = {}) {
  const doc = options.document || (typeof document !== 'undefined' ? document : undefined);
  const coordinator = createCoordinator({ ...options, isActive: () => !doc?.hidden && (!options.isActive || options.isActive()) });
  const visible = () => coordinator.resume();
  doc?.addEventListener('visibilitychange', visible);
  const dispose = coordinator.dispose;
  coordinator.dispose = () => { doc?.removeEventListener('visibilitychange', visible); dispose(); };
  return coordinator;
}

const DATE_POLICY_VERSION = '2026-10-03';

function marketFromCountry(country) {
  const value = String(country || '').trim().toLowerCase();
  if (['ng', 'nga', 'nigeria', 'ngn'].includes(value)) return 'NG';
  if (['gb', 'gbr', 'uk', 'united kingdom', 'great britain', 'gbp'].includes(value)) return 'GB';
  return 'OTHER';
}

function canonicalUkNation(nation) {
  const value = String(nation || '').trim().toLowerCase().replace(/[_-]+/g, ' ');
  if (value === 'england') return 'England';
  if (value === 'scotland') return 'Scotland';
  if (value === 'wales') return 'Wales';
  if (['northern ireland', 'n ireland', 'ni'].includes(value)) return 'Northern Ireland';
  return null;
}

function startOfCalendarDay(value = new Date()) {
  const match = typeof value === 'string' && /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  const date = match
    ? new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]))
    : new Date(value);
  if (Number.isNaN(date.getTime())) throw new TypeError('A valid date is required');
  date.setHours(0, 0, 0, 0);
  return date;
}

function dateOnly(value = new Date()) {
  const date = startOfCalendarDay(value);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function addCalendarDays(value, days) {
  const date = startOfCalendarDay(value);
  date.setDate(date.getDate() + Number(days || 0));
  return date;
}

function addCalendarMonths(value, months) {
  const date = startOfCalendarDay(value);
  const targetDay = date.getDate();
  date.setDate(1);
  date.setMonth(date.getMonth() + Number(months || 0));
  const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  date.setDate(Math.min(targetDay, lastDay));
  return date;
}

function addCalendarYears(value, years) {
  return addCalendarMonths(value, Number(years || 0) * 12);
}

function latestDate(...values) {
  const dates = values.filter(Boolean).map(startOfCalendarDay);
  return dates.reduce((latest, value) => value > latest ? value : latest);
}

function rentIncreaseRules(country, ukNation) {
  if (marketFromCountry(country) !== 'GB') {
    return { noticeMonths: 0, minimumGapMonths: 0, firstIncreaseDelayMonths: 0, source: 'agreement-or-local-policy' };
  }
  const nation = canonicalUkNation(ukNation);
  if (nation === 'England') {
    return { noticeMonths: 2, minimumGapMonths: 12, firstIncreaseDelayMonths: 12, source: 'england' };
  }
  if (nation === 'Wales') {
    return { noticeMonths: 2, minimumGapMonths: 12, firstIncreaseDelayMonths: 0, source: 'wales' };
  }
  if (nation === 'Scotland') {
    return { noticeMonths: 3, minimumGapMonths: 12, firstIncreaseDelayMonths: 0, source: 'scotland' };
  }
  if (nation === 'Northern Ireland') {
    return { noticeMonths: 3, minimumGapMonths: 12, firstIncreaseDelayMonths: 12, source: 'northern-ireland' };
  }
  // A missing nation must never make a UK picker offer less notice than a known nation.
  return { noticeMonths: 3, minimumGapMonths: 12, firstIncreaseDelayMonths: 12, source: 'uk-safe-default' };
}

function getDatePolicy(kind, options = {}) {
  const today = startOfCalendarDay(options.today || new Date());
  const result = { kind, version: DATE_POLICY_VERSION, minDate: null, maxDate: null };
  switch (kind) {
    case 'adult-date-of-birth':
      result.minDate = dateOnly(addCalendarYears(today, -120));
      result.maxDate = dateOnly(addCalendarYears(today, -18));
      break;
    case 'document-issue':
      result.maxDate = dateOnly(today);
      break;
    case 'document-expiry':
    case 'future-event':
      result.minDate = dateOnly(today);
      break;
    case 'bill-due':
      result.minDate = dateOnly(options.issueDate || today);
      break;
    case 'rent-increase': {
      const rule = rentIncreaseRules(options.country, options.ukNation);
      const configured = Number(options.noticeMonths || 0);
      const candidates = [
        addCalendarMonths(today, Math.max(rule.noticeMonths, configured)),
        addCalendarDays(today, Number(options.noticeDays || 0)),
      ];
      if (options.tenancyStartDate && rule.firstIncreaseDelayMonths) {
        candidates.push(addCalendarMonths(options.tenancyStartDate, rule.firstIncreaseDelayMonths));
      }
      if (options.lastIncreaseDate && rule.minimumGapMonths) {
        candidates.push(addCalendarMonths(options.lastIncreaseDate, rule.minimumGapMonths));
      }
      result.minDate = dateOnly(latestDate(...candidates));
      result.noticeMonths = Math.max(rule.noticeMonths, configured);
      result.noticeDays = Math.max(0, Number(options.noticeDays || 0));
      result.minimumGapMonths = rule.minimumGapMonths;
      result.firstIncreaseDelayMonths = rule.firstIncreaseDelayMonths;
      result.source = rule.source;
      break;
    }
    case 'gas-safety-expiry':
      if (options.issueDate) result.maxDate = dateOnly(addCalendarMonths(options.issueDate, 12));
      break;
    case 'electrical-safety-expiry':
      if (options.issueDate) result.maxDate = dateOnly(addCalendarMonths(options.issueDate, 60));
      break;
    case 'epc-expiry':
      if (options.issueDate) result.maxDate = dateOnly(addCalendarMonths(options.issueDate, 120));
      break;
    case 'deposit-protection-deadline':
      if (options.receivedDate) result.maxDate = dateOnly(addCalendarDays(options.receivedDate, 30));
      break;
    default:
      throw new RangeError('Unknown date policy: ' + kind);
  }
  return Object.freeze(result);
}

function isDateWithinPolicy(value, policy) {
  const selected = dateOnly(value);
  if (policy.minDate && selected < policy.minDate) return false;
  if (policy.maxDate && selected > policy.maxDate) return false;
  return true;
}

module.exports = {
  policies,
  eventDomains,
  createCoordinator,
  createBrowserCoordinator,
  DATE_POLICY_VERSION,
  marketFromCountry,
  canonicalUkNation,
  dateOnly,
  addCalendarDays,
  addCalendarMonths,
  addCalendarYears,
  rentIncreaseRules,
  getDatePolicy,
  isDateWithinPolicy,
};
