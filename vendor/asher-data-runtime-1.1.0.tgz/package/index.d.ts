export type Domain = 'notifications' | 'chat' | 'support' | 'maintenance' | 'inspections' | 'finance' | 'dashboard' | 'applications' | 'community' | 'analytics' | 'verification' | 'payment' | 'capture';
export const policies: Readonly<Record<Domain, { staleMs: number; reconcileMs: number }>>;
export const eventDomains: Readonly<Record<string, Domain[]>>;
export interface WatchOptions {
  /** Must include account ID and resource ID for resources with different loaders. */
  key: string;
  domain: Domain;
  load: (signal: AbortSignal) => unknown | Promise<unknown>;
  isActive?: () => boolean;
  onError?: (error: unknown) => void;
  immediate?: boolean;
  intervalMs?: number;
}
export interface Coordinator {
  watch(options: WatchOptions): () => void;
  invalidate(domains: Domain[]): void;
  resume(): void;
  bindSocket(socket: { on(event: string, handler: (...args: any[]) => void): any; off(event: string, handler: (...args: any[]) => void): any }): () => void;
  dispose(): void;
  size(): number;
}
export interface CoordinatorOptions {
  isActive?: () => boolean;
  maxConcurrent?: number;
  now?: () => number;
  timers?: { setTimeout(callback: () => void, delay: number): any; clearTimeout(id: any): void };
}
export function createCoordinator(options?: CoordinatorOptions): Coordinator;
export function createBrowserCoordinator(options?: CoordinatorOptions & { document?: Document }): Coordinator;
export type MarketCode = 'GB' | 'NG' | 'OTHER';
export type UkNation = 'England' | 'Scotland' | 'Wales' | 'Northern Ireland';
export type DatePolicyKind = 'adult-date-of-birth' | 'document-issue' | 'document-expiry' | 'future-event' | 'bill-due' | 'rent-increase' | 'gas-safety-expiry' | 'electrical-safety-expiry' | 'epc-expiry' | 'deposit-protection-deadline';
export interface DatePolicyOptions {
  today?: Date | string;
  country?: string | null;
  ukNation?: string | null;
  issueDate?: Date | string | null;
  receivedDate?: Date | string | null;
  tenancyStartDate?: Date | string | null;
  lastIncreaseDate?: Date | string | null;
  noticeMonths?: number | null;
  noticeDays?: number | null;
}
export interface DatePolicy {
  kind: DatePolicyKind;
  version: string;
  minDate: string | null;
  maxDate: string | null;
  noticeMonths?: number;
  noticeDays?: number;
  minimumGapMonths?: number;
  firstIncreaseDelayMonths?: number;
  source?: string;
}
export const DATE_POLICY_VERSION: string;
export function marketFromCountry(country?: string | null): MarketCode;
export function canonicalUkNation(nation?: string | null): UkNation | null;
export function dateOnly(value?: Date | string): string;
export function addCalendarDays(value: Date | string, days: number): Date;
export function addCalendarMonths(value: Date | string, months: number): Date;
export function addCalendarYears(value: Date | string, years: number): Date;
export function rentIncreaseRules(country?: string | null, ukNation?: string | null): Readonly<{ noticeMonths: number; minimumGapMonths: number; firstIncreaseDelayMonths: number; source: string }>;
export function getDatePolicy(kind: DatePolicyKind, options?: DatePolicyOptions): Readonly<DatePolicy>;
export function isDateWithinPolicy(value: Date | string, policy: DatePolicy): boolean;
